var fondo = document.querySelector('.padre')
var fuego = document.querySelector('.sprite')
var ruedados = document.querySelector('.ruedas2')
var ruedauno = document.querySelector('.ruedas1')
var luzcarro = document.querySelector('.tapar')

fondo.addEventListener('click',atras)

function atras(){
    fondo.classList.add('fondo')
    fuego.classList.add('sprite')
    ruedados.classList.add('r2')
    ruedauno.classList.add('r1')
    fuego.classList.remove('ocultar')
    luzcarro.classList.remove('tapar')
}